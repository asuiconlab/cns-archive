Dear Sir/Madam,

The manuscript is contained in the following files:
- text.doc - The text in MS Word format
- fig1.eps - Fig 1
- fig2.eps - Fig 2

I tried whether the text fits 6 pages in the Neurocomputing format.
So I converted it to this format, which you can view in files:
- CNS02_Bogacz_formatted.doc
- CNS02_Bogacz_formatted.pdf

As you can see the paper fits 6 pages. If you still have any problems 
with fitting the paper, you can make Figure 1 as small as you want.

Thank you very much.

Best wishes,

Rafal Bogacz